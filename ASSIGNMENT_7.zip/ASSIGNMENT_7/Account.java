import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Account {
    private static int accountCounter = 1;
    private final int accountNumber;
    private final String type;
    private double balance;
    private final List<Transaction> transactions = new ArrayList<>();

    public Account(String type, double initialDeposit) {
        this.accountNumber = accountCounter++;
        this.type = type;
        this.balance = initialDeposit;
        logTransaction("Initial Deposit", initialDeposit);
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public double getBalance() {
        return balance;
    }

    public void deposit(double amount) {
        balance += amount;
        logTransaction("Deposit", amount);
    }

    public boolean withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
            logTransaction("Withdrawal", amount);
            return true;
        }
        return false;
    }

    public void printStatement() {
        System.out.println("Transaction History for Account " + accountNumber + ":");
        for (Transaction transaction : transactions) {
            System.out.println(transaction);
        }
    }

    private void logTransaction(String type, double amount) {
        transactions.add(new Transaction(type, amount, new Date()));
    }
}
