import java.util.Date;

public class Transaction {
    private final String type;
    private final double amount;
    private final Date date;

    public Transaction(String type, double amount, Date date) {
        this.type = type;
        this.amount = amount;
        this.date = date;
    }

    @Override
    public String toString() {
        return date + " - " + type + ": $" + amount;
    }
}
