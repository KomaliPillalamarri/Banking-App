import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class User {
    private final String username;
    private final String password;
    private final List<Account> accounts = new ArrayList<>();

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void openAccount(Scanner scanner) {
        System.out.print("Enter account type (savings/checking): ");
        String type = scanner.nextLine();
        System.out.print("Enter initial deposit amount: ");
        double initialDeposit = scanner.nextDouble();
        scanner.nextLine(); // consume newline
        Account newAccount = new Account(type, initialDeposit);
        accounts.add(newAccount);
        System.out.println("Account created successfully.");
    }

    public void deposit(Scanner scanner) {
        Account account = selectAccount(scanner);
        if (account != null) {
            System.out.print("Enter deposit amount: ");
            double amount = scanner.nextDouble();
            scanner.nextLine(); // consume newline
            account.deposit(amount);
            System.out.println("Deposit successful.");
        }
    }

    public void withdraw(Scanner scanner) {
        Account account = selectAccount(scanner);
        if (account != null) {
            System.out.print("Enter withdrawal amount: ");
            double amount = scanner.nextDouble();
            scanner.nextLine(); // consume newline
            if (account.withdraw(amount)) {
                System.out.println("Withdrawal successful.");
            } else {
                System.out.println("Insufficient funds.");
            }
        }
    }

    public void checkBalance(Scanner scanner) {
        Account account = selectAccount(scanner);
        if (account != null) {
            System.out.println("Current balance: $" + account.getBalance());
        }
    }

    public void viewStatement(Scanner scanner) {
        Account account = selectAccount(scanner);
        if (account != null) {
            account.printStatement();
        }
    }

    private Account selectAccount(Scanner scanner) {
        System.out.println("Select account by number:");
        for (int i = 0; i < accounts.size(); i++) {
            System.out.println((i + 1) + ". " + accounts.get(i).getAccountNumber());
        }
        int choice = scanner.nextInt();
        scanner.nextLine(); // consume newline
        return choice > 0 && choice <= accounts.size() ? accounts.get(choice - 1) : null;
    }
}
