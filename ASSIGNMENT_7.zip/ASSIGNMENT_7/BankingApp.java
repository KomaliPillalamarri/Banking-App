import java.util.*;

public class BankingApp {
    public static final Scanner scanner = new Scanner(System.in);
    private static final List<User> users = new ArrayList<>();
    private static User loggedInUser = null;

    public static void main(String[] args) {
        while (true) {
            if (loggedInUser == null) {
                System.out.println("1. Register\n2. Login\n3. Exit");
                int choice = scanner.nextInt();
                scanner.nextLine(); // consume newline
                switch (choice) {
                    case 1 -> register();
                    case 2 -> login();
                    case 3 -> System.exit(0);
                    default -> System.out.println("Invalid option.");
                }
            } else {
                System.out.println("1. Open Account\n2. Deposit\n3. Withdraw\n4. Check Balance\n5. View Statement\n6. Logout");
                int choice = scanner.nextInt();
                scanner.nextLine(); // consume newline
                switch (choice) {
                    case 1 -> loggedInUser.openAccount(scanner);
                    case 2 -> loggedInUser.deposit(scanner);
                    case 3 -> loggedInUser.withdraw(scanner);
                    case 4 -> loggedInUser.checkBalance(scanner);
                    case 5 -> loggedInUser.viewStatement(scanner);
                    case 6 -> loggedInUser = null;
                    default -> System.out.println("Invalid option.");
                }
            }
        }
    }

    private static void register() {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        users.add(new User(username, password));
        System.out.println("Registration successful.");
    }

    private static void login() {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        for (User user : users) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                loggedInUser = user;
                System.out.println("Login successful.");
                return;
            }
        }
        System.out.println("Invalid credentials.");
    }
}
